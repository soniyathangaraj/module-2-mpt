package assignments;

public class AgeException extends Exception {

	public AgeException(String exp) {
		System.out.println(exp);
	}
	
	

}
